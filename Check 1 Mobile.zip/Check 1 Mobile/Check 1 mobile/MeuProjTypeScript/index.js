var nome = "Olavo";
var idade = 45;
var ativo = true;
console.log("Nome: ".concat(nome));
console.log("Idade: ".concat(idade));
console.log("Ativo: ".concat(ativo));
