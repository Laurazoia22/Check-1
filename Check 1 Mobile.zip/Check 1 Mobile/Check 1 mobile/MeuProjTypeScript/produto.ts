// Exercício 2: Funções e Interfaces

interface Livro {
    titulo: string;
    autor: string;
    anoPublicacao: number;
}

function exibirInformacoes(livro: Livro): string {
    return `O livro "${livro.titulo}" foi escrito por ${livro.autor} e publicado em ${livro.anoPublicacao}.`;
}

const livro1: Livro = {
    titulo: "O morro dos ventos uivantes",
    autor: "Emily Bronte",
    anoPublicacao: 1847
};

console.log(exibirInformacoes(livro1));