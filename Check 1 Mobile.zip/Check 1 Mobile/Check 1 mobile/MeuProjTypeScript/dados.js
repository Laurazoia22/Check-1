// Exercício 1: Tipagem Básica
var cidade = "Campos do Jordão";
var temperatura = 14;
var chovendo = true;
console.log("Cidade: ".concat(cidade));
console.log("Temperatura: ".concat(temperatura));
console.log("Chovendo: ".concat(chovendo));
