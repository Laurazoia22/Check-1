let nome: string = "Olavo";
let idade: number = 45;
let ativo: boolean = true;

console.log(`Nome: ${nome}`);
console.log(`Idade: ${idade}`);
console.log(`Ativo: ${ativo}`);
