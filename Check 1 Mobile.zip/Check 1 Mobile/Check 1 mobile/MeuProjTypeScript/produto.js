// Exercício 2: Funções e Interfaces
function exibirInformacoes(livro) {
    return "O livro \"".concat(livro.titulo, "\" foi escrito por ").concat(livro.autor, " e publicado em ").concat(livro.anoPublicacao, ".");
}
var livro1 = {
    titulo: "O morro dos ventos uivantes ",
    autor: "Emily Bronte",
    anoPublicacao: 1847
};
console.log(exibirInformacoes(livro1));
