// Exercício 1: Tipagem Básica

let cidade: string = "Campos do Jordao";
let temperatura: number = 14;
let chovendo: boolean = true;

console.log(`Cidade: ${cidade}`);
console.log(`Temperatura: ${temperatura}`);
console.log(`Chovendo: ${chovendo}`);
