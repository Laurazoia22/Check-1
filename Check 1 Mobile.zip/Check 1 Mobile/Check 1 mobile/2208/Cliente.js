"use strict";
// Modulo chamado Cliente.ts, que exporta uma classe Cliente com as propriedades nome (string) e email (string).
Object.defineProperty(exports, "__esModule", { value: true });
exports.Cliente = void 0;
var Cliente = /** @class */ (function () {
    function Cliente(nome, email) {
        this.nome = nome;
        this.email = email;
    }
    return Cliente;
}());
exports.Cliente = Cliente;
