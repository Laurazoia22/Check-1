// Modulo chamado Cliente.ts, que exporta uma classe Cliente com as propriedades nome (string) e email (string).

export class Cliente {
    constructor(public nome: string, public email: string) {}
}

